/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication1;

import java.util.ArrayList;
import java.util.List;


/**
 *
 * @author varisha ajaz
 */
 
public class Courses {
	public String Name;
	public int Course_Id;
    List <Students> los= new ArrayList<Students>();
    //List <>lot= new List(); add trainer here    
}
