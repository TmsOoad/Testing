/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication1;

import java.util.Date;
import java.awt.List;

 
public class Students {
    public int id;
public int age;
public Date signup_date;
public String payment_status;
public String name;
public String contact;
public String address;
public String occupation;
public String email;
public String status;
List a= new List ();
public void prov_feed (String feed)
{
	
	}
}
